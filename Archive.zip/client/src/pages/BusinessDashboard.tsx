import { motion, AnimatePresence } from "framer-motion";
import { Phone, Calendar, Palette, ArrowLeft, Loader2, ChevronDown, FileText } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { AuthWidget } from "@/components/AuthWidget";

interface CallLog {
  id: number;
  userId: number | null;
  userEmail: string | null;
  title: string;
  summary: string | null;
  notes: string | null;
  style: string | null;
  palette: string | null;
  finish: string | null;
  createdAt: string;
}

export default function BusinessDashboard() {
  const { user, token, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [logs, setLogs] = useState<CallLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [expandedLogId, setExpandedLogId] = useState<number | null>(null);

  useEffect(() => {
    if (!authLoading && (!user || user.accountType !== "business")) {
      setLocation("/");
    }
  }, [user, authLoading, setLocation]);

  useEffect(() => {
    if (token && user?.accountType === "business") {
      fetch("/api/call-logs", {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((res) => {
          if (!res.ok) throw new Error("Failed to fetch logs");
          return res.json();
        })
        .then((data) => setLogs(data))
        .catch((err) => setError(err.message))
        .finally(() => setIsLoading(false));
    }
  }, [token, user]);

  if (authLoading) {
    return (
      <div className="h-screen w-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user || user.accountType !== "business") {
    return null;
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle, currentColor 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />

      <header className="h-14 border-b border-border/50 flex items-center justify-between px-6 bg-background/80 backdrop-blur-sm sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back</span>
          </button>
          <span className="text-muted-foreground/30">|</span>
          <h1 className="font-medium">Business Dashboard</h1>
        </div>
        <AuthWidget />
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div>
            <h2 className="text-2xl font-semibold mb-2">Call Logs</h2>
            <p className="text-muted-foreground">
              View all consultation calls and their details
            </p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : error ? (
            <div className="text-center py-12 text-muted-foreground">
              {error}
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No call logs yet
            </div>
          ) : (
            <div className="grid gap-4">
              {logs.map((log, index) => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="rounded-xl bg-card border border-border/50 hover:border-border transition-colors overflow-hidden"
                  data-testid={`card-call-log-${log.id}`}
                >
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
                          <Phone className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-medium truncate" data-testid={`text-title-${log.id}`}>
                            {log.title}
                          </h3>
                          {log.userEmail && (
                            <p className="text-xs text-muted-foreground/60 mt-0.5">
                              Client: {log.userEmail}
                            </p>
                          )}
                          {log.summary && (
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                              {log.summary}
                            </p>
                          )}
                          <div className="flex flex-wrap items-center gap-3 mt-3">
                            {log.style && (
                              <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md bg-muted text-muted-foreground">
                                <Palette className="w-3 h-3" />
                                {log.style}
                              </span>
                            )}
                            {log.palette && (
                              <span className="text-xs px-2 py-1 rounded-md bg-muted text-muted-foreground">
                                {log.palette}
                              </span>
                            )}
                            {log.finish && (
                              <span className="text-xs px-2 py-1 rounded-md bg-muted text-muted-foreground">
                                {log.finish}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          <span>{formatDate(log.createdAt)}</span>
                          <span className="text-muted-foreground/50">|</span>
                          <span>{formatTime(log.createdAt)}</span>
                        </div>
                        {log.notes && (
                          <button
                            onClick={() => setExpandedLogId(expandedLogId === log.id ? null : log.id)}
                            className="flex items-center gap-1 text-xs text-primary hover:text-primary/80 transition-colors"
                            data-testid={`button-expand-${log.id}`}
                          >
                            <FileText className="w-3 h-3" />
                            <span>Transcript</span>
                            <ChevronDown className={`w-3 h-3 transition-transform ${expandedLogId === log.id ? 'rotate-180' : ''}`} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <AnimatePresence>
                    {expandedLogId === log.id && log.notes && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="border-t border-border/50 bg-muted/30"
                      >
                        <div className="p-4 max-h-64 overflow-y-auto">
                          <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
                            Conversation Transcript
                          </h4>
                          <div className="space-y-2 text-sm whitespace-pre-wrap text-muted-foreground/80" style={{ fontSize: '12px' }}>
                            {log.notes}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </main>
    </div>
  );
}
