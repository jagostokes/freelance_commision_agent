import { motion, AnimatePresence } from "framer-motion";
import { WifiOff, Battery, Activity, ChevronDown, Info } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { AuthWidget } from "@/components/AuthWidget";
import { AuthModal } from "@/components/AuthModal";
import { useAuth } from "@/lib/auth";

import visualBriefImage from "@assets/01KCKS0AHGXH5FRV4KM3AP510V.optimized_1765895403737.png";
import iceSculptingImage from "@assets/01KCKS7KBDNHYWX8A1CJMDY000.optimized_1765895586826.png";
import gardeningImage from "@assets/01KCKSHNMEXEABS7CBETR2ZAQX.optimized_1765895990379.png";
import surfboardImage from "@assets/01KCKSRRMQWJJEEKTWVPY67W1E.optimized_1765896181662.png";

interface FreelancerOption {
  id: string;
  name: string;
  description: string;
  image: string;
  clickable: boolean;
  path?: string;
}

const FREELANCERS: FreelancerOption[] = [
  {
    id: "visual-brief",
    name: "Visual Brief",
    description: "AI-powered painting consultation agent",
    image: visualBriefImage,
    clickable: true,
    path: "/visual-brief",
  },
  {
    id: "ice-sculpting",
    name: "Ice Sculpting City",
    description: "Custom ice sculpture commissions",
    image: iceSculptingImage,
    clickable: false,
  },
  {
    id: "gardening",
    name: "Gardening Genius",
    description: "Landscape and garden design services",
    image: gardeningImage,
    clickable: false,
  },
  {
    id: "surfboard",
    name: "Surf Board Maniacs",
    description: "Custom surfboard design and shaping",
    image: surfboardImage,
    clickable: false,
  },
];

export default function Home() {
  const [time, setTime] = useState(new Date());
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [hoveredFreelancer, setHoveredFreelancer] = useState<FreelancerOption | null>(null);
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (user?.accountType === "business") {
      setLocation("/dashboard");
    }
  }, [user, setLocation]);

  const showLoginPrompt = !isLoading && !user;

  const handleFreelancerClick = (freelancer: FreelancerOption) => {
    if (freelancer.clickable && freelancer.path) {
      setLocation(freelancer.path);
    }
  };

  return (
    <div className="h-screen w-screen bg-background text-foreground flex flex-col overflow-hidden relative">
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle, currentColor 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />

      <div className="h-14 border-b border-border/50 flex items-center justify-between px-6 text-xs font-mono bg-background/80 backdrop-blur-sm relative z-10 shrink-0">
        <div className="flex items-center gap-4">
          <span className="text-muted-foreground">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <span className="text-muted-foreground/50">|</span>
          <span className="text-muted-foreground">
            {time.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
          </span>
        </div>
        
        <div className="flex items-center gap-4 text-muted-foreground">
          <div className="flex items-center gap-1">
            <Activity className="w-3 h-3" />
            <span className="text-[10px]">READY</span>
          </div>
          <WifiOff className="w-3 h-3" />
          <Battery className="w-4 h-4" />
          <div className="ml-2">
            <AuthWidget />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto relative z-10">
        <div className="min-h-full px-4 py-8">
          <div className="max-w-6xl mx-auto flex gap-8 items-start">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex-1 space-y-6"
            >
              <div className="space-y-3">
                <h1 className="text-4xl font-semibold tracking-tight">
                  Freelance Commission Ordering
                </h1>
                <p className="text-muted-foreground text-lg">
                  AI voice agents that streamline your creative commission process
                </p>
              </div>

              {showLoginPrompt && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col items-start gap-3 py-2"
                >
                  <p className="text-muted-foreground text-sm">
                    Log in to save your consultations and access your dashboard
                  </p>
                  <button
                    onClick={() => setShowAuthModal(true)}
                    className="h-10 px-6 rounded-lg bg-secondary text-secondary-foreground font-medium text-sm hover:bg-secondary/80 transition-colors"
                    data-testid="button-login-center"
                  >
                    Log In / Sign Up
                  </button>
                  <div className="text-xs text-muted-foreground/70">
                    <p>Demo: democlient@contrahackathon.com / democlient</p>
                    <p>Business: demobusiness@contrahackathon.com / demobusiness</p>
                  </div>
                </motion.div>
              )}

              <div className="pt-4">
                <div className="relative inline-block">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="h-14 px-8 rounded-xl bg-primary text-primary-foreground font-medium text-lg hover:bg-primary/90 transition-colors shadow-lg flex items-center gap-3"
                    data-testid="button-see-freelancers"
                  >
                    See Freelancers
                    <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${isDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  <AnimatePresence>
                    {isDropdownOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: -10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -10, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute top-full left-0 mt-2 flex z-50"
                      >
                        <div className="bg-card border border-border/50 rounded-xl shadow-xl overflow-hidden min-w-[320px]">
                          {FREELANCERS.map((freelancer) => (
                            <div
                              key={freelancer.id}
                              onMouseEnter={() => setHoveredFreelancer(freelancer)}
                              onMouseLeave={() => setHoveredFreelancer(null)}
                              onClick={() => handleFreelancerClick(freelancer)}
                              className={`p-4 border-b border-border/30 last:border-b-0 transition-colors ${
                                freelancer.clickable 
                                  ? 'hover:bg-primary/10 cursor-pointer' 
                                  : 'hover:bg-muted/50 cursor-not-allowed opacity-70'
                              }`}
                              data-testid={`freelancer-${freelancer.id}`}
                            >
                              <div className="flex items-center justify-between">
                                <div>
                                  <h3 className={`font-medium ${freelancer.clickable ? 'text-foreground' : 'text-muted-foreground'}`}>
                                    {freelancer.name}
                                  </h3>
                                  <p className="text-sm text-muted-foreground/70">
                                    {freelancer.description}
                                  </p>
                                </div>
                                {freelancer.clickable && (
                                  <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                  </svg>
                                )}
                                {!freelancer.clickable && (
                                  <span className="text-xs text-muted-foreground/50 bg-muted px-2 py-1 rounded">
                                    Coming Soon
                                  </span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>

                        <AnimatePresence>
                          {hoveredFreelancer && (
                            <motion.div
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -10 }}
                              transition={{ duration: 0.15 }}
                              className="ml-3 w-80 bg-card border border-border/50 rounded-xl shadow-xl overflow-hidden flex flex-col"
                            >
                              <div className="flex-1 h-72 overflow-hidden">
                                <img
                                  src={hoveredFreelancer.image}
                                  alt={hoveredFreelancer.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="p-3 border-t border-border/30 bg-muted/30">
                                <p className="text-xs text-muted-foreground text-center">
                                  Made with Tolstoy, all with the same prompt, just different product images
                                </p>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              <div className="h-96" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="hidden lg:block w-[422px] shrink-0"
            >
              <div className="p-5 rounded-xl bg-card/50 border border-border/50 backdrop-blur-sm sticky top-8">
                <div className="flex items-center gap-2 mb-3">
                  <Info className="w-4 h-4 text-primary" />
                  <span className="text-xs font-mono uppercase tracking-wider text-primary">Demo Note</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  Because Freelancers's time is money, I have set out to streamline the commissioning process.
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  To do this, I aimed to eliminate commissioner-client meetings, so the professionals can do the work they love most, without the long product specification meetings.
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  A freelancer would design an agent with this tool, along with all necessary specifications, and the voice agent will lead the client through all requisite information.
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  To do this, I have created a unique product, where a voice agent is able to share their screen. By loading in a database of images, the ElevenLabs connected to Anthropic API's is able to procure the meaning and intention of the commission by showing visual options… almost like it is sharing a screen! This enables the agent to narrow in on what exactly the client wants… and send the freelancer a to the point and comprehensive description.
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Hope you enjoy!
                </p>
                <p className="text-sm text-foreground mt-4 font-medium">
                  Jago Stokes
                </p>
                <p className="text-xs text-muted-foreground/70 mt-3 leading-relaxed">
                  Made with Replit Design Mode, Build Mode, Tolstoy Image Creation (all using one prompt/template and different products), TypeScript, React, Node.js, Express, PostgreSQL, TailwindCSS, Framer Motion, ElevenLabs ConvAI.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="h-8 border-t border-border/50 flex items-center justify-center text-[10px] text-muted-foreground/50 font-mono relative z-10 shrink-0">
        COMMISSION PLATFORM v1.0
      </div>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
}
