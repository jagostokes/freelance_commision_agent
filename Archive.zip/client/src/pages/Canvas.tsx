import { motion, AnimatePresence } from "framer-motion";
import { Mic, MicOff, Activity, Wifi, WifiOff, Battery, Menu, X, FileText, Check, Loader2, ArrowLeft, StickyNote } from "lucide-react";
import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import type { Session, UIPromptOption } from "@shared/schema";
import { AuthWidget } from "@/components/AuthWidget";
import { useAuth } from "@/lib/auth";

interface AgentNote {
  ts: number;
  message: string;
}

interface VisualPrompt {
  promptId: string;
  title: string;
  options: UIPromptOption[];
  toolCallId: string;
}

interface NoteEntry {
  ts: number;
  text: string;
  category?: string; // Used to prevent duplicate tool selection notes
}

interface TranscriptEntry {
  ts: number;
  speaker: "user" | "agent";
  text: string;
}

export default function Canvas() {
  const [, setLocation] = useLocation();
  const [time, setTime] = useState(new Date());
  const [isNotesOpen, setIsNotesOpen] = useState(false);
  const [notes, setNotes] = useState<NoteEntry[]>([]);
  
  // Session state
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);
  
  // Transcription
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
  const [streamingAgentText, setStreamingAgentText] = useState<string>(""); // Current agent text being streamed
  const [pendingUserTranscript, setPendingUserTranscript] = useState<string | null>(null); // Buffer user speech to show before agent
  const transcriptRef = useRef<HTMLDivElement>(null);
  
  // Visual prompts from agent
  const [currentPrompt, setCurrentPrompt] = useState<VisualPrompt | null>(null);
  const [todoPreview, setTodoPreview] = useState<string[] | null>(null);
  
  // Final summary
  const [showSummary, setShowSummary] = useState(false);
  const [summaryData, setSummaryData] = useState<Session | null>(null);
  
  // Agent notes (from send_note tool)
  const [agentNotes, setAgentNotes] = useState<AgentNote[]>([]);
  
  // WebSocket refs
  const elevenLabsWsRef = useRef<WebSocket | null>(null);
  const backendWsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const isMicActiveRef = useRef(false);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Auto-scroll transcript to bottom when new messages or streaming text arrive
  useEffect(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight;
    }
  }, [transcript, streamingAgentText]);

  const addNote = useCallback((text: string, category?: string) => {
    setNotes(prev => {
      // If category provided, remove any existing note with same category
      const filtered = category ? prev.filter(n => n.category !== category) : prev;
      return [...filtered, { ts: Date.now(), text, category }];
    });
  }, []);

  // Create session and connect
  const startCall = useCallback(async () => {
    if (isConnecting || isConnected) return;
    
    setIsConnecting(true);
    setTranscript([]); // Clear transcript for new session
    addNote("Hi there! I'm getting everything ready for our consultation...");

    try {
      // 1. Create session
      const sessionRes = await fetch("/api/session", { method: "POST" });
      const { sessionId: newSessionId } = await sessionRes.json();
      setSessionId(newSessionId);
      addNote("Perfect! Your session is set up. Let's talk about your painting vision.");

      // 2. Get ElevenLabs signed URL
      const signedUrlRes = await fetch("/api/elevenlabs/signed-url");
      if (!signedUrlRes.ok) {
        throw new Error("Failed to get ElevenLabs signed URL");
      }
      const { signed_url } = await signedUrlRes.json();

      // 3. Connect to backend WebSocket
      const wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const backendWs = new WebSocket(`${wsProtocol}//${window.location.host}/ws?sessionId=${newSessionId}`);
      backendWsRef.current = backendWs;

      backendWs.onopen = () => {
        console.log("Backend WS connected");
      };

      backendWs.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        console.log("Backend WS message:", msg);
        
        if (msg.type === "CALL_FINISHED") {
          handleCallFinished(newSessionId);
        } else if (msg.type === "TODO_PREVIEW") {
          setTodoPreview(msg.items);
          addNote("I've updated the task list based on our conversation.");
        }
      };

      // 4. Connect to ElevenLabs WebSocket
      const elevenLabsWs = new WebSocket(signed_url);
      elevenLabsWsRef.current = elevenLabsWs;

      elevenLabsWs.onopen = () => {
        console.log("ElevenLabs WS connected");
        setIsConnected(true);
        setIsConnecting(false);
        addNote("We're connected! I'm listening and ready to help you design your perfect piece.");
        startAudioCapture();
      };

      elevenLabsWs.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          handleElevenLabsMessage(msg, newSessionId);
        } catch (e) {
          console.error("Failed to parse ElevenLabs message:", e);
        }
      };

      elevenLabsWs.onerror = (error) => {
        console.error("ElevenLabs WS error:", error);
        addNote("Hmm, I ran into a connection issue. Let me try to reconnect...");
      };

      elevenLabsWs.onclose = () => {
        console.log("ElevenLabs WS closed");
        setIsConnected(false);
        setIsMicActive(false);
        addNote("Our call has ended. Thanks for chatting with me!");
      };

    } catch (error) {
      console.error("Failed to start call:", error);
      addNote(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
      setIsConnecting(false);
    }
  }, [isConnecting, isConnected, addNote]);

  // Helper to convert filename to label (e.g., "soft_light.jpg" -> "Soft Light")
  const filenameToLabel = (filename: string): string => {
    return filename
      .replace(/\.(jpg|jpeg|png|gif|webp)$/i, '') // Remove extension
      .split(/[_-]/) // Split on underscores or hyphens
      .map(word => word.charAt(0).toUpperCase() + word.slice(1)) // Capitalize each word
      .join(' ');
  };

  const sendToolResult = useCallback((toolCallId: string, result: string) => {
    if (elevenLabsWsRef.current?.readyState === WebSocket.OPEN) {
      elevenLabsWsRef.current.send(JSON.stringify({
        type: "client_tool_result",
        tool_call_id: toolCallId,
        result,
        is_error: false,
      }));
    }
  }, []);

  const handleElevenLabsMessage = useCallback((msg: any, currentSessionId: string) => {
    console.log("ElevenLabs event:", msg.type, msg);

    if (msg.type === "client_tool_call" && msg.client_tool_call) {
      const { tool_name, tool_call_id, parameters } = msg.client_tool_call;
      console.log("=== TOOL CALL RECEIVED ===");
      console.log("Tool name:", tool_name);
      console.log("Tool call ID:", tool_call_id);
      console.log("Parameters:", JSON.stringify(parameters, null, 2));
      console.log("=========================");
      
      // Handle dynamic image display tool
      if (tool_name === "show_style_options" || tool_name === "display_images") {
        // Parameters expected: { images: ["filename1.jpg", "filename2.jpg", ...], title?: string }
        const images: string[] = parameters?.images || [];
        const title = parameters?.title || "Choose a Style";
        
        if (images.length > 0) {
          const options = images.map((filename: string) => ({
            id: filename.replace(/\.(jpg|jpeg|png|gif|webp)$/i, ''),
            label: filenameToLabel(filename),
            image: `/assets/styles/${filename}`,
          }));
          
          setCurrentPrompt({
            promptId: `style_${Date.now()}`,
            title,
            toolCallId: tool_call_id,
            options,
          });
          addNote("Here are some style options for you to consider.");
        } else {
          sendToolResult(tool_call_id, "no images to display");
        }
        
      } else if (tool_name === "show_color_scheme" || tool_name === "show_color_schemes" || tool_name === "display_color_scheme" || tool_name === "show_palette_options") {
        const defaultColorSchemes = [
          "warm.png", "cool.png", "neutral.png", "earth-tone.png",
          "complementary.png", "analogous.png", "triadic.png", 
          "split-complementary.png", "tetradic.png"
        ];
        const images: string[] = parameters?.images?.length > 0 ? parameters.images : defaultColorSchemes;
        const title = parameters?.title || "Choose a Color Scheme";
        
        const options = images.map((filename: string) => ({
          id: filename.replace(/\.(jpg|jpeg|png|gif|webp)$/i, ''),
          label: filenameToLabel(filename),
          image: `/assets/color_scheme/${filename}`,
        }));
        
        setCurrentPrompt({
          promptId: `palette_${Date.now()}`,
          title,
          toolCallId: tool_call_id,
          options,
        });
        addNote("Here are some color schemes for you to consider.");
        
      } else if (tool_name === "show_finish_options") {
        const defaultFinishImages = ["glossy.png", "matte.png", "satin.png"];
        const images: string[] = parameters?.images?.length > 0 ? parameters.images : defaultFinishImages;
        const title = parameters?.title || "Choose a Finish";
        
        const options = images.map((filename: string) => ({
          id: filename.replace(/\.(jpg|jpeg|png|gif|webp)$/i, ''),
          label: filenameToLabel(filename),
          image: `/assets/finish/${filename}`,
        }));
        
        setCurrentPrompt({
          promptId: parameters?.promptId || "finish_1",
          title,
          toolCallId: tool_call_id,
          options,
        });
        addNote("Here are some finish options for you to consider.");
        
      } else if (tool_name === "show_todo_preview") {
        const items = parameters?.items || [];
        setTodoPreview(items);
        addNote("I've put together a summary of what we discussed. Let me know if this captures your vision!");
        
        // Auto-send result back
        sendToolResult(tool_call_id, "displayed todo preview");
        
      } else if (tool_name === "finish_call") {
        handleCallFinished(currentSessionId);
        sendToolResult(tool_call_id, "call finished");
        
      } else if (tool_name === "send_note") {
        const message = parameters?.message || "";
        console.log("send_note called with message:", message);
        if (message) {
          const noteId = Date.now();
          setAgentNotes(prev => [...prev, { ts: noteId, message }]);
          addNote(`Agent Note: ${message}`);
          
          // Auto-dismiss after 15 seconds
          setTimeout(() => {
            setAgentNotes(prev => prev.filter(n => n.ts !== noteId));
          }, 15000);
          
          if (backendWsRef.current?.readyState === WebSocket.OPEN) {
            backendWsRef.current.send(JSON.stringify({
              type: "AGENT_NOTE",
              message,
            }));
          }
        }
        sendToolResult(tool_call_id, "note recorded");
        
      } else {
        // Unknown tool - log it and send a generic response
        console.warn("Unknown tool called:", tool_name, parameters);
        addNote(`Tool called: ${tool_name}`);
        sendToolResult(tool_call_id, "acknowledged");
      }
    } else if (msg.type === "audio" && msg.audio_event?.audio_base_64) {
      // Handle audio playback from agent
      playAudioChunk(msg.audio_event.audio_base_64);
    } else if (msg.type === "user_transcript" && msg.user_transcription_event?.user_transcript) {
      // Capture user speech - add immediately before agent response
      const text = msg.user_transcription_event.user_transcript;
      if (text.trim()) {
        // Store the user transcript with a reference to add before agent response
        setPendingUserTranscript(text);
      }
    } else if (msg.type === "agent_chat_response_part" && msg.text_response_part) {
      // Handle streaming agent text - appears gradually as agent speaks
      const part = msg.text_response_part;
      if (part.type === "start") {
        // Flush any pending user transcript before agent starts
        setPendingUserTranscript(prev => {
          if (prev) {
            setTranscript(t => [...t, { ts: Date.now(), speaker: "user", text: prev }]);
          }
          return null;
        });
        // New agent message starting
        setStreamingAgentText("");
      } else if (part.type === "delta" && part.text) {
        // Append delta text to streaming message
        setStreamingAgentText(prev => prev + part.text);
      } else if (part.type === "stop") {
        // Agent finished speaking - finalize the message
        setStreamingAgentText(prev => {
          if (prev.trim()) {
            setTranscript(t => [...t, { ts: Date.now(), speaker: "agent", text: prev }]);
          }
          return "";
        });
      }
    }
  }, [addNote, sendToolResult]);

  const handleOptionSelect = useCallback((option: UIPromptOption) => {
    if (!currentPrompt || !sessionId) return;

    // Send to ElevenLabs
    sendToolResult(currentPrompt.toolCallId, option.id);

    // Send to backend for persistence
    if (backendWsRef.current?.readyState === WebSocket.OPEN) {
      backendWsRef.current.send(JSON.stringify({
        type: "UI_RESPONSE",
        promptId: currentPrompt.promptId,
        selectedOptionId: option.id,
      }));
    }

    // Determine category from promptId to prevent duplicate notes
    let category: string | undefined;
    if (currentPrompt.promptId.startsWith("style")) {
      category = "selection_style";
    } else if (currentPrompt.promptId.startsWith("palette") || currentPrompt.promptId.startsWith("color")) {
      category = "selection_palette";
    } else if (currentPrompt.promptId.startsWith("finish")) {
      category = "selection_finish";
    }

    addNote(`Great choice! You selected "${option.label}" - I'm noting that down.`, category);
    setCurrentPrompt(null);
  }, [currentPrompt, sessionId, sendToolResult, addNote]);

  const handleTodoConfirm = useCallback((ok: boolean) => {
    if (backendWsRef.current?.readyState === WebSocket.OPEN) {
      backendWsRef.current.send(JSON.stringify({
        type: "TODO_CONFIRM",
        ok,
      }));
    }
    
    if (ok) {
      addNote("Wonderful! I've locked in your preferences. We're making great progress!");
      setTodoPreview(null);
    } else {
      addNote("No problem! Let's revisit and refine your brief together.");
    }
  }, [addNote]);

  const handleCallFinished = useCallback(async (finishedSessionId: string) => {
    addNote("That's a wrap! I've captured everything we discussed. Your painting brief is ready for the artist.");
    
    // Fetch final session data
    try {
      const res = await fetch(`/api/session/${finishedSessionId}`);
      const session = await res.json();
      setSummaryData(session);
      setShowSummary(true);
      
      // Build transcript notes from the conversation
      const transcriptNotes = transcript.map(entry => 
        `${entry.speaker === "agent" ? "Agent" : "User"}: ${entry.text}`
      ).join("\n\n");
      
      // Save call log with notes
      const token = localStorage.getItem("authToken");
      await fetch("/api/call-logs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          title: `Commission Brief - ${new Date().toLocaleDateString()}`,
          summary: session.brief?.style ? `Style: ${session.brief.style}` : "Consultation completed",
          notes: transcriptNotes || null,
          style: session.brief?.style || null,
          palette: session.brief?.palette || null,
          finish: session.brief?.finish || null,
        }),
      });
    } catch (error) {
      console.error("Failed to fetch session summary:", error);
    }
    
    // Cleanup
    stopAudioCapture();
    elevenLabsWsRef.current?.close();
    backendWsRef.current?.close();
    setIsConnected(false);
  }, [addNote, transcript]);

  const startAudioCapture = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      audioContextRef.current = new AudioContext({ sampleRate: 16000 });
      
      const source = audioContextRef.current.createMediaStreamSource(stream);
      const processor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
      
      processor.onaudioprocess = (e) => {
        // Use ref to avoid stale closure
        if (elevenLabsWsRef.current?.readyState === WebSocket.OPEN && isMicActiveRef.current) {
          const inputData = e.inputBuffer.getChannelData(0);
          const pcmData = new Int16Array(inputData.length);
          for (let i = 0; i < inputData.length; i++) {
            pcmData[i] = Math.max(-32768, Math.min(32767, inputData[i] * 32768));
          }
          
          // Convert to base64 for ElevenLabs
          const uint8Array = new Uint8Array(pcmData.buffer);
          let binary = '';
          for (let i = 0; i < uint8Array.length; i++) {
            binary += String.fromCharCode(uint8Array[i]);
          }
          
          // Send in ElevenLabs expected format
          elevenLabsWsRef.current.send(JSON.stringify({
            user_audio_chunk: btoa(binary),
          }));
        }
      };
      
      source.connect(processor);
      processor.connect(audioContextRef.current.destination);
      
      // Update both state and ref
      isMicActiveRef.current = true;
      setIsMicActive(true);
    } catch (error) {
      console.error("Failed to start audio capture:", error);
      addNote("I couldn't access your microphone. Please allow mic access so we can chat!");
    }
  }, [addNote]);

  const stopAudioCapture = useCallback(() => {
    // Stop all tracks
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    audioContextRef.current?.close();
    audioContextRef.current = null;
    
    // Update both state and ref
    isMicActiveRef.current = false;
    setIsMicActive(false);
  }, []);

  // Audio playback context and queue
  const playbackContextRef = useRef<AudioContext | null>(null);
  const audioQueueRef = useRef<Float32Array[]>([]);
  const isPlayingRef = useRef(false);

  const playAudioChunk = useCallback((base64Audio: string) => {
    try {
      // Decode base64 to binary
      const binaryString = atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert to Int16Array (PCM 16-bit)
      const int16Array = new Int16Array(bytes.buffer);
      
      // Convert Int16 to Float32 for Web Audio API
      const float32Array = new Float32Array(int16Array.length);
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768;
      }

      // Queue the audio chunk
      audioQueueRef.current.push(float32Array);

      // Start playback if not already playing
      if (!isPlayingRef.current) {
        playNextChunk();
      }
    } catch (e) {
      console.error("Failed to process audio:", e);
    }
  }, []);

  const playNextChunk = useCallback(() => {
    if (audioQueueRef.current.length === 0) {
      isPlayingRef.current = false;
      return;
    }

    isPlayingRef.current = true;

    // Get or create audio context
    if (!playbackContextRef.current) {
      playbackContextRef.current = new AudioContext({ sampleRate: 16000 });
    }

    const ctx = playbackContextRef.current;
    const float32Data = audioQueueRef.current.shift()!;

    // Create buffer and source
    const buffer = ctx.createBuffer(1, float32Data.length, 16000);
    buffer.getChannelData(0).set(float32Data);

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.onended = playNextChunk;
    source.start();
  }, []);

  const toggleMic = useCallback(() => {
    if (isMicActiveRef.current) {
      stopAudioCapture();
    } else {
      startAudioCapture();
    }
  }, [startAudioCapture, stopAudioCapture]);

  const endCall = useCallback(() => {
    if (sessionId) {
      handleCallFinished(sessionId);
    }
  }, [sessionId, handleCallFinished]);

  return (
    <div className="h-screen w-screen bg-background text-foreground overflow-hidden flex flex-col relative bg-dot-pattern">
      {/* Status Bar */}
      <header className="h-12 border-b border-border/40 backdrop-blur-sm flex items-center justify-between px-6 z-10 bg-background/50">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-xs font-medium">Back</span>
          </button>
          <div className="h-4 w-[1px] bg-border/50" />
          <div className="flex items-center gap-2 text-primary/80">
            <Activity className="w-4 h-4" />
            <span className="text-xs font-mono font-medium tracking-wider uppercase">
              VisualBrief Commission Agent: {isConnected ? "Online" : "Offline"}
            </span>
          </div>
          <div className="h-4 w-[1px] bg-border/50" />
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-muted-foreground/50'}`} />
            <span className="text-xs font-mono text-muted-foreground">
              {sessionId ? `ID: ${sessionId}` : "No Session"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-xs font-mono text-muted-foreground tabular-nums">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
          <div className="flex items-center gap-3 text-muted-foreground">
            {isConnected ? <Wifi className="w-4 h-4 text-emerald-500" /> : <WifiOff className="w-4 h-4" />}
            <Battery className="w-4 h-4" />
          </div>
          <AuthWidget />
        </div>
      </header>

      {/* Agent Notes Display - Top Right */}
      <AnimatePresence>
        {agentNotes.length > 0 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="fixed top-16 right-4 z-50 w-80 max-h-[60vh] overflow-y-auto"
          >
            <div className="bg-card border border-primary/30 rounded-xl shadow-lg overflow-hidden">
              <div className="px-4 py-2 bg-primary/10 border-b border-primary/20 flex items-center gap-2">
                <StickyNote className="w-4 h-4 text-primary" />
                <span className="text-xs font-mono uppercase tracking-wider text-primary">Agent Notes</span>
                <span className="text-xs text-primary/60">({agentNotes.length})</span>
              </div>
              <div className="p-3 space-y-2 max-h-64 overflow-y-auto">
                {agentNotes.map((note, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-2 text-sm"
                  >
                    <span className="text-primary shrink-0">*</span>
                    <div>
                      <span className="text-xs text-primary/70 uppercase font-mono">AGENT RECORDED A NOTE: </span>
                      <span className="text-foreground/80">{note.message}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Canvas Area */}
      <main className="flex-1 relative flex overflow-hidden">
        {/* Transcript Panel - Left Side */}
        {isConnected && (
          <div className="w-72 border-r border-border/30 p-4 overflow-hidden flex flex-col">
            <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground/50 mb-3">
              Transcript
            </div>
            <div 
              ref={transcriptRef}
              className="flex-1 overflow-y-auto space-y-3 pr-2"
              style={{ scrollBehavior: 'smooth' }}
            >
              {transcript.map((entry, idx) => (
                <div key={idx} className="text-xs leading-relaxed" style={{ fontSize: '12px' }}>
                  <span className={entry.speaker === "agent" ? "text-muted-foreground/60" : "text-muted-foreground/40"}>
                    {entry.speaker === "agent" ? "Agent: " : "You: "}
                  </span>
                  <span className="text-muted-foreground/50">
                    {entry.text}
                  </span>
                </div>
              ))}
              {/* Show streaming agent text as it's being spoken */}
              {streamingAgentText && (
                <div className="text-xs leading-relaxed" style={{ fontSize: '12px' }}>
                  <span className="text-muted-foreground/60">Agent: </span>
                  <span className="text-muted-foreground/50">{streamingAgentText}</span>
                  <span className="inline-block w-1 h-3 bg-muted-foreground/30 animate-pulse ml-0.5" />
                </div>
              )}
              {transcript.length === 0 && !streamingAgentText && (
                <p className="text-xs text-muted-foreground/30 italic">
                  Conversation will appear here...
                </p>
              )}
            </div>
          </div>
        )}

        {/* Center Content Area */}
        <div className="flex-1 relative flex items-center justify-center p-8">
        
        {/* Empty State */}
        {!isConnected && !currentPrompt && !showSummary && (
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center gap-6 text-center"
            >
              <div className="w-24 h-24 border-2 border-dashed border-muted-foreground/20 rounded-xl flex items-center justify-center">
                <div className="w-2 h-2 bg-muted-foreground/20 rounded-full" />
              </div>
              <div className="space-y-2 text-center">
                <p className="font-mono text-sm tracking-[0.2em] uppercase text-muted-foreground/40">Commission Agent Is Sharing Its Screen</p>
                <p className="text-sm text-muted-foreground/60 max-w-xs mx-auto">
                  Transcript, Notes, and Preferences will be sent to Visual Briefs LLC to begin your commission.
                </p>
              </div>
            </motion.div>
          </div>
        )}

        {/* Visual Prompt Cards */}
        <AnimatePresence mode="wait">
          {currentPrompt && (
            <motion.div
              key={currentPrompt.promptId}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-4xl"
            >
              <div className="text-center mb-8">
                <h2 className="text-2xl font-light text-foreground">Agent is displaying:</h2>
              </div>
              <div className="grid grid-cols-3 gap-6">
                {currentPrompt.options.map((option) => (
                  <motion.button
                    key={option.id}
                    onClick={() => handleOptionSelect(option)}
                    className="group relative aspect-[4/3] rounded-xl overflow-hidden border border-border/50 bg-card hover:border-primary/50 transition-all duration-300"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    data-testid={`option-${option.id}`}
                  >
                    <img 
                      src={option.image} 
                      alt={option.label}
                      className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://placehold.co/400x300/1a1a2e/ffffff?text=${option.label}`;
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <p className="text-lg font-medium text-white">{option.label}</p>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Todo Preview */}
        <AnimatePresence>
          {todoPreview && !currentPrompt && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-lg"
            >
              <div className="bg-card border border-border/50 rounded-xl p-6 space-y-4">
                <h3 className="text-lg font-medium">Proposed Next Steps</h3>
                <ul className="space-y-2">
                  {todoPreview.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => handleTodoConfirm(true)}
                    className="flex-1 py-2 px-4 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
                    data-testid="button-confirm-todos"
                  >
                    <Check className="w-4 h-4" /> Confirm
                  </button>
                  <button
                    onClick={() => handleTodoConfirm(false)}
                    className="flex-1 py-2 px-4 rounded-lg bg-secondary text-secondary-foreground font-medium hover:bg-secondary/80 transition-colors"
                    data-testid="button-revise-todos"
                  >
                    Revise
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Final Summary */}
        <AnimatePresence>
          {showSummary && summaryData && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="w-full max-w-2xl"
            >
              <div className="bg-card border border-border/50 rounded-xl p-8 space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 flex items-center justify-center">
                    <Check className="w-8 h-8 text-emerald-500" />
                  </div>
                  <h2 className="text-2xl font-light">Consultation Complete</h2>
                  <p className="text-sm text-muted-foreground">Your painting brief has been saved</p>
                </div>
                
                <div className="space-y-4 pt-4 border-t border-border/50">
                  {summaryData.brief.style && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Style</span>
                      <span className="font-medium capitalize">{summaryData.brief.style}</span>
                    </div>
                  )}
                  {summaryData.brief.palette && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Palette</span>
                      <span className="font-medium capitalize">{summaryData.brief.palette}</span>
                    </div>
                  )}
                  {summaryData.brief.finish && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Finish</span>
                      <span className="font-medium capitalize">{summaryData.brief.finish}</span>
                    </div>
                  )}
                  {summaryData.brief.timeline && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Timeline</span>
                      <span className="font-medium">{summaryData.brief.timeline}</span>
                    </div>
                  )}
                  {summaryData.brief.budget && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Budget</span>
                      <span className="font-medium">{summaryData.brief.budget}</span>
                    </div>
                  )}
                </div>

                {summaryData.approvals.length > 0 && (
                  <div className="space-y-2 pt-4 border-t border-border/50">
                    <h4 className="text-sm font-medium text-muted-foreground">Decisions Made</h4>
                    <ul className="text-sm space-y-1">
                      {summaryData.approvals.slice(-5).map((a, idx) => (
                        <li key={idx} className="text-muted-foreground/80">{a.text}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  onClick={() => {
                    setShowSummary(false);
                    setSummaryData(null);
                    setSessionId(null);
                    setNotes([]);
                    setTranscript([]);
                    setCurrentPrompt(null);
                    setTodoPreview(null);
                    setIsConnected(false);
                    setIsConnecting(false);
                    setIsMicActive(false);
                  }}
                  className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
                  data-testid="button-new-consultation"
                >
                  Start New Consultation
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Notes Panel */}
        <AnimatePresence>
          {isNotesOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsNotesOpen(false)}
                className="absolute inset-0 bg-background/60 backdrop-blur-sm z-20"
              />
              
              <motion.div
                initial={{ y: "100%", opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: "100%", opacity: 0 }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="absolute bottom-0 left-0 right-0 z-30 flex flex-col items-center justify-end pointer-events-none p-6"
              >
                <div 
                  className="w-full max-w-2xl bg-card border border-border/50 rounded-t-xl shadow-2xl pointer-events-auto flex flex-col h-[60vh] overflow-hidden"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="h-12 border-b border-border/50 flex items-center justify-between px-4 bg-muted/30">
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <FileText className="w-4 h-4 text-primary" />
                      <span>Running Notes</span>
                      <span className="text-xs text-muted-foreground">({notes.length} entries)</span>
                    </div>
                    <button 
                      onClick={() => setIsNotesOpen(false)}
                      className="w-8 h-8 rounded-full hover:bg-background/50 flex items-center justify-center transition-colors text-muted-foreground hover:text-foreground"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-4 space-y-2">
                    {notes.length === 0 ? (
                      <p className="text-sm text-muted-foreground/50 text-center py-8">
                        Notes will appear here as the consultation progresses...
                      </p>
                    ) : (
                      notes.map((note, idx) => (
                        <div key={idx} className="text-sm text-muted-foreground flex gap-3">
                          <span className="text-muted-foreground/50 shrink-0 tabular-nums">
                            {new Date(note.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <span>{note.text}</span>
                        </div>
                      ))
                    )}
                  </div>
                  
                  <div className="h-8 border-t border-border/50 bg-muted/10 flex items-center justify-between px-4 text-[10px] text-muted-foreground font-mono">
                    <span>SESSION LOG</span>
                    <span>LIVE</span>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
        </div>
      </main>

      {/* Control Bar */}
      <footer className="h-20 border-t border-border/40 backdrop-blur-md flex items-center justify-center z-10 bg-background/50 relative">
        <div className="flex items-center gap-6">
          <button 
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 group ${isNotesOpen ? 'bg-primary text-primary-foreground' : 'bg-secondary/50 hover:bg-secondary text-muted-foreground hover:text-foreground'}`}
            data-testid="button-menu"
            onClick={() => setIsNotesOpen(!isNotesOpen)}
          >
            <Menu className={`w-5 h-5 transition-transform duration-300 ${isNotesOpen ? 'rotate-90' : ''}`} />
          </button>
          
          <div className="h-12 px-6 rounded-full bg-secondary/30 border border-white/5 flex items-center gap-4 min-w-[300px]">
            {isConnecting ? (
              <>
                <Loader2 className="w-4 h-4 text-primary animate-spin" />
                <span className="text-sm text-muted-foreground font-light">Connecting...</span>
              </>
            ) : isConnected ? (
              <>
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-sm text-muted-foreground font-light">
                  {isMicActive ? "Listening..." : "Mic muted"}
                </span>
              </>
            ) : (
              <>
                <div className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50" />
                <span className="text-sm text-muted-foreground font-light">Click mic to start</span>
              </>
            )}
          </div>

          <button 
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors group relative ${
              isConnected 
                ? isMicActive 
                  ? 'bg-emerald-500/20 hover:bg-emerald-500/30' 
                  : 'bg-destructive/20 hover:bg-destructive/30'
                : 'bg-primary/10 hover:bg-primary/20'
            }`}
            data-testid="button-mic"
            onClick={isConnected ? toggleMic : startCall}
            disabled={isConnecting}
          >
            {isConnected && isMicActive && (
              <motion.div 
                className="absolute inset-0 rounded-full bg-emerald-500/20"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
              />
            )}
            {isConnected ? (
              isMicActive ? (
                <Mic className="w-5 h-5 text-emerald-500 relative z-10" />
              ) : (
                <MicOff className="w-5 h-5 text-destructive relative z-10" />
              )
            ) : (
              <Mic className="w-5 h-5 text-primary relative z-10" />
            )}
          </button>

          {isConnected && (
            <button
              onClick={endCall}
              className="w-12 h-12 rounded-full bg-destructive/20 hover:bg-destructive/30 flex items-center justify-center transition-colors"
              data-testid="button-end-call"
            >
              <X className="w-5 h-5 text-destructive" />
            </button>
          )}
        </div>
      </footer>
    </div>
  );
}
